# web-dev-template

1. git clone https://github.com/jannunzi/web-dev-template.git
1. cd web-dev-template
1. npm install
1. mongod
1. node server.js
1. browse to localhost:3000
